library(testthat)
library(gaiaCore)

test_check("gaiaCore")
