# gaiaCore Development Version 0.1.0

The initial development version of gaiaCore starts with the version of the gaiaCore R Package that was presented at the 2024 Global OHDSI Symposium ([this commit](https://github.com/OHDSI/GIS/commit/601a1245fb33647c8b5b8101278edec8dcce5323)).
